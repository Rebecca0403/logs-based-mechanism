from django.apps import AppConfig


class LogsdetailConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'logsdetail'
