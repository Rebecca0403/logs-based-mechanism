import logging
logging.basicConfig(filename='app.log', filemode='w',format='%(asctime)s - %(levelname)s - %(message)s', level=logging.INFO)
logging.info('Admin logged in')
try:
    print(x)
except Exception as e:
    print(e) 
    # logging.basicConfig(format='%(asctime)s - %(message)s', level=logging.INFO)
    # logging.info('Test LogInformation',e)
    logging.error("%s",e)
    logging.warning(e)
    
    