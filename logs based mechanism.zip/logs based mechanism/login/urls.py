from django.urls import path,include
from login import views

urlpatterns = [
    
    path('', views.index),
    path('register/', views.register),
    path('home/', views.home, name='home'),
    path('error_time/', views.error_time, name='error_time'),
    path('error_type/', views.error_type, name='error_type'),
    path('logout/', views.user_logout, name='logout'),

]

