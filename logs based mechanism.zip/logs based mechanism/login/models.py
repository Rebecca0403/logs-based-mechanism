from time import time
from django.db import models

# Create your models here.
class Logsinformation(models.Model):
    type_error=models.CharField(max_length=50)
    error_time=models.TimeField()
    error_message=models.CharField(max_length=50)
    def __str__(self):
        return str(self.type_error)+" "+str(self.error_time)+" "+str(self.error_message)
