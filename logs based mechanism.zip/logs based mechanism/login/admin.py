from django.contrib import admin
from login.models import Logsinformation

# Register your models here. 
admin.site.register(Logsinformation)
